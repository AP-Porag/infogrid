<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>SKU:</strong> <?php echo e($item->sku); ?></p>
                                        <p><strong>Item Type:</strong> <?php echo e($item->itemType); ?></p>
                                        <p><strong>Created By:</strong> <?php echo e($item->user->first_name.' '.$item->user->last_name); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Created At:</strong> <?php echo e($item->created_at->format('d M Y H:i')); ?></p>
                                        <p><strong>Last Updated:</strong> <?php echo e($item->updated_at->format('d M Y H:i')); ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <h5 class="mt-3">Equipment Specifications</h5>
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover spec-table">
                                                <thead>
                                                <tr>
                                                    <th>Parameter</th>
                                                    <th>Rated Value</th>
                                                    <th>Measured Value</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php if($item->itemType === 'Pump'): ?>
                                                    <!-- Pump Specifications -->
                                                    <tr>
                                                        <td>Year of Installation</td>
                                                        <td><?php echo e($item->pumpYearOfInstallationRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpYearOfInstallationMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Flow</td>
                                                        <td><?php echo e($item->pumpFlowRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpFlowMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Head</td>
                                                        <td><?php echo e($item->pumpHeadRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpHeadMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Voltage</td>
                                                        <td><?php echo e($item->pumpVoltageRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpVoltageMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Current</td>
                                                        <td><?php echo e($item->pumpCurrentRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpCurrentMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Power Factor</td>
                                                        <td><?php echo e($item->pumpPowerFactorRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpPowerFactorMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Power</td>
                                                        <td><?php echo e($item->pumpMotorPowerRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpMotorPowerMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency</td>
                                                        <td><?php echo e($item->pumpMotorEfficiencyRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpMotorEfficiencyMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency Class</td>
                                                        <td><?php echo e($item->pumpMotorEfficiencyClassRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpMotorEfficiencyClassMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Frame Size</td>
                                                        <td><?php echo e($item->pumpMotorFrameSizeRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpMotorFrameSizeMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Insulation Class</td>
                                                        <td><?php echo e($item->pumpInsulationClassRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpInsulationClassMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Suction Head</td>
                                                        <td><?php echo e($item->pumpSuctionHeadRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpSuctionHeadMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Discharge Head</td>
                                                        <td><?php echo e($item->pumpDischargeHeadRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpDischargeHeadMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Efficiency</td>
                                                        <td><?php echo e($item->pumpEfficiencyRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->pumpEfficiencyMeasured ?? '-'); ?></td>
                                                    </tr>

                                                <?php elseif($item->itemType === 'Fan'): ?>
                                                    <!-- Fan Specifications -->
                                                    <tr>
                                                        <td>Year of Installation</td>
                                                        <td><?php echo e($item->fanYearOfInstallationRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanYearOfInstallationMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Flow</td>
                                                        <td><?php echo e($item->fanFlowRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanFlowMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Head</td>
                                                        <td><?php echo e($item->fanHeadRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanHeadMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Voltage</td>
                                                        <td><?php echo e($item->fanVoltageRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanVoltageMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Current</td>
                                                        <td><?php echo e($item->fanCurrentRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanCurrentMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Power Factor</td>
                                                        <td><?php echo e($item->fanPowerFactorRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanPowerFactorMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Power</td>
                                                        <td><?php echo e($item->fanMotorPowerRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanMotorPowerMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency</td>
                                                        <td><?php echo e($item->fanMotorEfficiencyRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanMotorEfficiencyMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency Class</td>
                                                        <td><?php echo e($item->fanMotorEfficiencyClassRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanMotorEfficiencyClassMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Frame Size</td>
                                                        <td><?php echo e($item->fanMotorFrameSizeRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanMotorFrameSizeMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Insulation Class</td>
                                                        <td><?php echo e($item->fanInsulationClassRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanInsulationClassMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Suction Duct Size</td>
                                                        <td><?php echo e($item->fanSuctionDuctSizeRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanSuctionDuctSizeMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Suction Static Pressure</td>
                                                        <td><?php echo e($item->fanSuctionStaticPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanSuctionStaticPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Suction Velocity Pressure</td>
                                                        <td><?php echo e($item->fanSuctionVelocityPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanSuctionVelocityPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Discharge Duct Size</td>
                                                        <td><?php echo e($item->fanDischargeDuctSizeRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanDischargeDuctSizeMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Discharge Static Pressure</td>
                                                        <td><?php echo e($item->fanDischargeStaticPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanDischargeStaticPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Discharge Velocity Pressure</td>
                                                        <td><?php echo e($item->fanDischargeVelocityPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanDischargeVelocityPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Efficiency</td>
                                                        <td><?php echo e($item->fanEfficiencyRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->fanEfficiencyMeasured ?? '-'); ?></td>
                                                    </tr>

                                                <?php elseif($item->itemType === 'Air Compressor'): ?>
                                                    <!-- Air Compressor Specifications -->
                                                    <tr>
                                                        <td>Year of Installation</td>
                                                        <td><?php echo e($item->airCompressorYearOfInstallationRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorYearOfInstallationMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Flow</td>
                                                        <td><?php echo e($item->airCompressorFlowRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorFlowMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Pressure</td>
                                                        <td><?php echo e($item->airCompressorPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Voltage</td>
                                                        <td><?php echo e($item->airCompressorVoltageRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorVoltageMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Current</td>
                                                        <td><?php echo e($item->airCompressorCurrentRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorCurrentMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Power Factor</td>
                                                        <td><?php echo e($item->airCompressorPowerFactorRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorPowerFactorMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Power</td>
                                                        <td><?php echo e($item->airCompressorMotorPowerRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorMotorPowerMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency</td>
                                                        <td><?php echo e($item->airCompressorMotorEfficiencyRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorMotorEfficiencyMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency Class</td>
                                                        <td><?php echo e($item->airCompressorMotorEfficiencyClassRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorMotorEfficiencyClassMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Frame Size</td>
                                                        <td><?php echo e($item->airCompressorMotorFrameSizeRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorMotorFrameSizeMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Insulation Class</td>
                                                        <td><?php echo e($item->airCompressorInsulationClassRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorInsulationClassMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Load Pressure</td>
                                                        <td><?php echo e($item->airCompressorLoadPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorLoadPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>UnLoad Pressure</td>
                                                        <td><?php echo e($item->airCompressorUnLoadPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorUnLoadPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Receiver Size</td>
                                                        <td><?php echo e($item->airCompressorRecieverSizeRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorRecieverSizeMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Initial Pressure</td>
                                                        <td><?php echo e($item->airCompressorInitialPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorInitialPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Final Pressure</td>
                                                        <td><?php echo e($item->airCompressorFinalPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorFinalPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Time to Reach Final Pressure</td>
                                                        <td><?php echo e($item->airCompressorTimeToReachFinalPressureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorTimeToReachFinalPressureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Temperature</td>
                                                        <td><?php echo e($item->airCompressorTemperatureRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorTemperatureMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Compressor SEC</td>
                                                        <td><?php echo e($item->airCompressorCompressorSECRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->airCompressorCompressorSECMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <!-- Leakage Test -->
                                                    <tr>
                                                        <td>Load Time Reading One</td>
                                                        <td colspan="2"><?php echo e($item->airCompressorLoadTimeReadingOne ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Load Time Reading Two</td>
                                                        <td colspan="2"><?php echo e($item->airCompressorLoadTimeReadingTwo ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>UnLoad Time Reading One</td>
                                                        <td colspan="2"><?php echo e($item->airCompressorUnLoadTimeReadingOne ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>UnLoad Time Reading Two</td>
                                                        <td colspan="2"><?php echo e($item->airCompressorUnLoadTimeReadingTwo ?? '-'); ?></td>
                                                    </tr>

                                                <?php elseif($item->itemType === 'Chiller'): ?>
                                                    <!-- Chiller Specifications -->
                                                    <tr>
                                                        <td>Year of Installation</td>
                                                        <td><?php echo e($item->chillerYearOfInstallationRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerYearOfInstallationMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Capacity</td>
                                                        <td><?php echo e($item->chillerCapacityRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerCapacityMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Voltage</td>
                                                        <td><?php echo e($item->chillerVoltageRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerVoltageMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Current</td>
                                                        <td><?php echo e($item->chillerCurrentRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerCurrentMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Power Factor</td>
                                                        <td><?php echo e($item->chillerPowerFactorRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerPowerFactorMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Power</td>
                                                        <td><?php echo e($item->chillerMotorPowerRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerMotorPowerMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency</td>
                                                        <td><?php echo e($item->chillerMotorEfficiencyRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerMotorEfficiencyMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency Class</td>
                                                        <td><?php echo e($item->chillerMotorEfficiencyClassRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerMotorEfficiencyClassMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Frame Size</td>
                                                        <td><?php echo e($item->chillerMotorFrameSizeRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerMotorFrameSizeMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Supply Temp</td>
                                                        <td><?php echo e($item->chillerSupplyTempRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerSupplyTempMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Return Temp</td>
                                                        <td><?php echo e($item->chillerReturnTempRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerReturnTempMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Flow</td>
                                                        <td><?php echo e($item->chillerFlowRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerFlowMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Chiller SEC</td>
                                                        <td><?php echo e($item->chillerChillerSECRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerChillerSECMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Condenser Approach</td>
                                                        <td><?php echo e($item->chillerCondenserApprochRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->chillerCondenserApprochMeasured ?? '-'); ?></td>
                                                    </tr>

                                                <?php elseif($item->itemType === 'Motor'): ?>
                                                    <!-- Motor Specifications -->
                                                    <tr>
                                                        <td>Year of Installation</td>
                                                        <td><?php echo e($item->motorYearOfInstallationRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->motorYearOfInstallationMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Name of Equipment</td>
                                                        <td><?php echo e($item->motorNameOfEquipmentRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->motorNameOfEquipmentMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Voltage</td>
                                                        <td><?php echo e($item->motorVoltageRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->motorVoltageMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Current</td>
                                                        <td><?php echo e($item->motorCurrentRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->motorCurrentMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Power Factor</td>
                                                        <td><?php echo e($item->motorPowerFactorRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->motorPowerFactorMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Power</td>
                                                        <td><?php echo e($item->motorMotorPowerRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->motorMotorPowerMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency</td>
                                                        <td><?php echo e($item->motorMotorEfficiencyRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->motorMotorEfficiencyMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Efficiency Class</td>
                                                        <td><?php echo e($item->motorMotorEfficiencyClassRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->motorMotorEfficiencyClassMeasured ?? '-'); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Motor Frame Size</td>
                                                        <td><?php echo e($item->motorMotorFrameSizeRated ?? '-'); ?></td>
                                                        <td><?php echo e($item->motorMotorFrameSizeMeasured ?? '-'); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <p><strong>Observations:</strong></p>
                                <p><?php echo e($item->observations ?? 'No observations recorded'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="row">
                                    <?php $__currentLoopData = $item->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6 mb-4">
                                            <img src="<?php echo e(Storage::url($image->image)); ?>" alt="Product image"
                                                 style="height: 180px; width: 180px; object-fit: cover; border-radius: 10px;">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <h5 class="mt-3">Checklist</h5>
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <th>Check Item</th>
                                            <th>Value/Status</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if($item->itemType === 'Pump'): ?>
                                            <!-- Pump Checklist -->
                                            <tr>
                                                <td>VFD or Not</td>
                                                <td><?php echo e($item->pumpVFDorNot ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>VFD Setting</td>
                                                <td><?php echo e($item->pumpVFDSetting ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Throttling</td>
                                                <td><?php echo e($item->pumpThrottling ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Flow Modulation Required</td>
                                                <td><?php echo e($item->pumpFlowModulationRequired ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Parallel Pump Operation</td>
                                                <td><?php echo e($item->pumpParallelPumpOperation ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>No. of Rewinding of Motor</td>
                                                <td><?php echo e($item->pumpNosOfRewidingOfMotor ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Check Cavitation</td>
                                                <td><?php echo e($item->pumpCheckCavitation ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Operating Hours</td>
                                                <td><?php echo e($item->pumpOperatingHours ?? '-'); ?></td>
                                            </tr>

                                        <?php elseif($item->itemType === 'Fan'): ?>
                                            <!-- Fan Checklist -->
                                            <tr>
                                                <td>VFD or Not</td>
                                                <td><?php echo e($item->fanVFDorNot ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>VFD Setting</td>
                                                <td><?php echo e($item->fanVFDSetting ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Opening</td>
                                                <td><?php echo e($item->fanOpening ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Flow Modulation Required</td>
                                                <td><?php echo e($item->fanFlowModulationRequired ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Parallel Fan Operation</td>
                                                <td><?php echo e($item->fanParallelFanOperation ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>No. of Rewinding of Motor</td>
                                                <td><?php echo e($item->fanNosOfRewidingOfMotor ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Operating Hours</td>
                                                <td><?php echo e($item->fanOperatingHours ?? '-'); ?></td>
                                            </tr>

                                        <?php elseif($item->itemType === 'Air Compressor'): ?>
                                            <!-- Air Compressor Checklist -->
                                            <tr>
                                                <td>VFD or Not</td>
                                                <td><?php echo e($item->airCompressorVFDorNot ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>No. of Rewinding of Motor</td>
                                                <td><?php echo e($item->airCompressorNosOfRewidingOfMotor ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Check Required Pressure</td>
                                                <td><?php echo e($item->airCompressorCheckRequiredpressure ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Check Pressure Drop</td>
                                                <td><?php echo e($item->airCompressorCheckPressureDrop ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Operating Hours</td>
                                                <td><?php echo e($item->airCompressorOperatingHours ?? '-'); ?></td>
                                            </tr>

                                        <?php elseif($item->itemType === 'Chiller'): ?>
                                            <!-- Chiller Checklist -->
                                            <tr>
                                                <td>VFD or Not</td>
                                                <td><?php echo e($item->chillerVFDorNot ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Set Temp</td>
                                                <td><?php echo e($item->chillerSetTemp ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Check Condenser Condition</td>
                                                <td><?php echo e($item->chillerCheckCondenserCondition ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Operating Hours</td>
                                                <td><?php echo e($item->chillerOperatingHours ?? '-'); ?></td>
                                            </tr>

                                        <?php elseif($item->itemType === 'Motor'): ?>
                                            <!-- Motor Checklist -->
                                            <tr>
                                                <td>VFD or Not</td>
                                                <td><?php echo e($item->motorVFDorNot ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Check Per Phase Current</td>
                                                <td><?php echo e($item->motorCheckPerPhaseCurrent ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Check Phasor</td>
                                                <td><?php echo e($item->motorCheckPhasor ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>No. of Rewinding of Motor</td>
                                                <td><?php echo e($item->motorNosOfRewidingOfMotor ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Operating Hours</td>
                                                <td><?php echo e($item->motorOperatingHours ?? '-'); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Basic Information Card -->
































































































































































































































































































































































































































































































































































































































    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .data-card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .header-section {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 10px 10px 0 0;
        }
        .table-responsive {
            max-height: 500px;
            overflow-y: auto;
        }
        .table th {
            position: sticky;
            top: 0;
            background-color: white;
        }
        .spec-table th, .spec-table td {
            vertical-align: middle;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\infogrid\resources\views/admin/information/show.blade.php ENDPATH**/ ?>