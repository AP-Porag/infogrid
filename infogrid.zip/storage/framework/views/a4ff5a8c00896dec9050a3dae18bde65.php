<meta charset="utf-8">
<meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>">
<meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords'); ?>">
<title><?php echo e(get_page_meta()); ?> <?php echo e(config('settings.site_title') ?? config('app.name')); ?></title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- App favicon -->
<!--Favicon-->
<link rel="icon" href="<?php echo e(asset('/storage/settings/favicon.ico')); ?>" />
<link rel="icon" href="<?php echo e(asset('/storage/logo-light.png')); ?>" type="image/svg+xml" />


<!-- Select2 CSS -->
<link href="<?php echo e(asset('admin/libs/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css">

<!-- Bootstrap Css -->
<link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css">
<!-- Icons Css -->
<link href="<?php echo e(asset('admin/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
<!-- App Css-->
<link href="<?php echo e(asset('admin/css/app.css')); ?>" id="app-style" rel="stylesheet" type="text/css">

<link href="<?php echo e(asset('admin/toastr/toastr.min.css')); ?>" rel="stylesheet" type="text/css">

<link href="<?php echo e(asset('admin/sweetalert/sweetalert.min.css')); ?>" rel="stylesheet" type="text/css">

<link href="<?php echo e(asset('admin/css/custom-dev.css')); ?>" rel="stylesheet" type="text/css">

<?php echo $__env->yieldPushContent('style'); ?>
<?php /**PATH D:\laragon\www\infogrid\resources\views/layouts/partials/_head.blade.php ENDPATH**/ ?>