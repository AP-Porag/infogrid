<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!-- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Main</li>

                <li>
                    <a href="<?php echo e(route('home')); ?>" class="waves-effect">
                        <i class="fa fa-home"></i><span> Dashboard </span>
                    </a>
                </li>

























            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH D:\laragon\www\infogrid\resources\views/layouts/partials/sidebars/_sidebar-user.blade.php ENDPATH**/ ?>