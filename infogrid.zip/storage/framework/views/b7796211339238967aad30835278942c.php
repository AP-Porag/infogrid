<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('layouts.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body data-sidebar="dark">

<div id="app">
    <!-- Begin page -->
    <div id="layout-wrapper">

        <?php if(!request()->is('/') && !request()->is('login')): ?>
            <?php echo $__env->make('layouts.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <!-- ========== Left Sidebar Start ========== -->
        <?php if(!request()->is('/') && !request()->is('login')): ?>
            <?php echo $__env->make('layouts.partials.sidebars._sidebar-'.auth()->user()->user_type, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <!-- Left Sidebar End -->

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="<?php echo e(request()->is('login') ? '':'page-content'); ?>">
                <div class="container-fluid">

                    <!-- start page title -->
                    <?php if(!request()->is('/') && !request()->is('login')): ?>
                        <?php echo $__env->make('layouts.partials._breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <!-- end page title -->


                    <!-- Start Your Main Content Here-->
                    <?php echo $__env->yieldContent('content'); ?>

                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

            <?php if(!request()->is('/') && !request()->is('login')): ?>
                <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->
</div>

<!-- JAVASCRIPT -->
<?php echo $__env->make('layouts.partials._footer-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH D:\laragon\www\infogrid\resources\views/layouts/master.blade.php ENDPATH**/ ?>