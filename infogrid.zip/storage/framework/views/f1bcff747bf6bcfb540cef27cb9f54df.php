<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3">Update Profile</h4>

                    <div class="row">
                        <div class="col-md-4">
                            <form id="adminAvatarUpdateForm" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="avatar-upload">
                                    <div class="avatar-edit">
                                        <input type='file' name="avatar" id="adminImageUpload" accept=".png, .jpg, .jpeg" />
                                        <label for="adminImageUpload"></label>
                                    </div>
                                    <div class="avatar-preview">
                                        <div id="imagePreview" style="background-image: url('<?php echo e($user->avatar_url); ?>');">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="col-md-6">
                            <form action="<?php echo e(route('admin.profile.update', $user->id)); ?>" method="POST" id="form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-group mb-2">
                                    <label for="first_name">
                                        First Name <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" id="first_name" name="first_name" class="form-control"
                                           autocomplete="off" value="<?php echo e($user->first_name); ?>"
                                           placeholder="Enter your first name" required>
                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group mb-2">
                                    <label for="middle_name">
                                        Middle Name <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" id="middle_name" name="middle_name" class="form-control"
                                           autocomplete="off" value="<?php echo e($user->middle_name); ?>"
                                           placeholder="Enter your middle name">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="middle_name"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group mb-2">
                                    <label for="last_name">
                                        Last Name <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" id="last_name" name="last_name" class="form-control"
                                           autocomplete="off" value="<?php echo e($user->last_name); ?>" placeholder="Enter your last name"
                                           required>
                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group mb-2">
                                    <label for="phone">
                                        Phone Number <span class="text-danger">*</span>
                                    </label>
                                    <input type="tel" class="form-control" id="phone" name="phone" autocomplete="off"
                                           value="<?php echo e($user->phone); ?>" required>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-2">
                                    <label class="form-label">Email <span class="error">*</span></label>
                                    <input type="email" name="email" class="form-control" required="" placeholder="Email"
                                           value="<?php echo e($user->email); ?>">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>























                                <button type="submit" class="btn btn-primary waves-effect waves-light">
                                    Update Profile
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3">Update Password</h4>
                    <div class="row">
                        <div class="col-md-8">
                            <form action="<?php echo e(route('admin.update.password')); ?>" method="POST" id="form2">
                                <?php echo csrf_field(); ?>

                                <div class="form-group mb-2">
                                    <label for="c_password">Current Password<span class="text-danger">*</span></label>
                                    <input id="c_password" type="password" class="form-control" name="current_password"
                                           autocomplete="current-password" placeholder="Enter current password" required>
                                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-2">
                                    <label for="new_password">New Password <span class="text-danger">*</span></label>
                                    <input id="new_password" type="password" class="form-control" name="new_password"
                                           placeholder="Enter new password" autocomplete="current-password" required>
                                    <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="new_confirm_password">Confirm New Password <span
                                            class="text-danger">*</span></label>
                                    <input id="new_confirm_password" type="password" class="form-control"
                                           name="new_password_confirmation" placeholder="Confirm new password"
                                           autocomplete="current-password" required>

                                </div>

                                <button type="submit" class="btn btn-primary waves-effect waves-light">
                                    Update Password
                                </button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <!-- profile font -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#adminImageUpload").on("change",function() {
            readURL(this);
            uploadUserProfileImage();
        });

        function uploadUserProfileImage() {
            let myForm = document.getElementById('adminAvatarUpdateForm');
            let formData = new FormData(myForm);
            $.ajax({
                type: 'POST',
                data: formData,
                dataType: 'JSON',
                contentType: false,
                cache: false,
                processData: false,
                url: "<?php echo e(route('admin.avatar.update')); ?>",
                success: function(result) {
                    Swal.fire({
                        icon: 'success',
                        title: result.success
                    })
                }.bind($(this))
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\infogrid\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>