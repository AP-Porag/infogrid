<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                © {{ date('Y') }}
            </div>
        </div>
    </div>
</footer>
